﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalcLibrary
{
    public static class Loop
    {
        // User options
        public static string[] mainMenu = { "Add", "Subtract", "Multiply", "Divide", "Exit" };
        public static string[] subMenu = { "Repeat", "Main Menu" };

        public static string DoMain()
        {
            // Clear the console
            Console.Clear();

            // Initialize variables
            string menuOption;

            // Get User Choice from Main Menu
            menuOption = UI.GetMenuOption(mainMenu);

            // Return menuOption
            return menuOption;
        }

        public static string DoSub(string option)
        {
            // Initialize variables
            string menuOption;

            // Display option
            Console.WriteLine(option);

            // Get User Input
            int a = UI.GetInput();
            int b = UI.GetInput();
            int ans = 0;
            char symbol = ' ';

            // Switch using option
            switch (option)
            {
                case "Add":
                    // Add 2 numbers
                    ans = Calc.Add(a, b);

                    // Change symbol
                    symbol = '+';
                    break;

                case "Subtract":
                    // Subtract 2 numbers
                    ans = Calc.Subtract(a, b);

                    // Change symbol
                    symbol = '-';
                    break;

                case "Multiply":
                    // Multiply 2 numbers
                    ans = Calc.Multiply(a, b);

                    // Change symbol
                    symbol = '*';
                    break;

                case "Divide":
                    // Divide 2 numbers
                    try
                    {
                        // Divide
                        ans = Calc.Divide(a, b);
                    }
                    catch (Exception e)
                    {
                        // Divide by 0 error
                        Console.WriteLine(e.Message);
                    }
                    finally
                    {
                        // Change symbol
                        symbol = '/';
                    }
                    break;
            }

            // Display answer equation
            UI.ShowAnswer(a, b, ans, symbol);

            // Get user choice from Sub Menu
            menuOption = UI.GetMenuOption(subMenu);

            // If menuOption is Main Menu
            if (menuOption == "Main Menu")
            {
                // Return Main Menu
                return menuOption;
            }
            // If menuOption is Repeat
            else
            {
                // Return the previous option
                return option;
            }
        }
    }
}
