﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalcLibrary
{
    public static class UI
    {
        /// <summary>
        /// Shows the options menu to the user
        /// </summary>
        public static void ShowMenu(string[] options)
        {
            // Display Options
            for (int i = 0; i < options.Length; i++)
            {
                Console.WriteLine($"{i + 1}.{options[i]}");
            }
        }

        /// <summary>
        /// Gets the string input from the user and converts it to an int
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static int GetInput()
        {
            // Int variables
            int intInput = 0;

            // Prompt user
            Console.Write("Enter a number: ");

            // Get input from user
            if (int.TryParse(Console.ReadLine(), out intInput))
            {
                // If input can be converted
                return intInput;
            }
            else
            {
                // If input cannot be converted
                return 0;
            }
        }

        /// <summary>
        /// Shows the answer of a calculation
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <param name="ans"></param>
        /// <param name="symbol"></param>
        public static void ShowAnswer(double a, double b, double ans, char symbol)
        {
            Console.WriteLine($"{a} {symbol} {b} = {ans}");
        }

        /// <summary>
        /// Get an option from an array using an index
        /// </summary>
        /// <param name="options"></param>
        /// <param name="index"></param>
        /// <returns></returns>
        public static string GetMenuOption(string[] options)
        {
            // Initialize variables
            string menuOption;

            // Choice loop
            do
            {
                // Show the options to the user
                ShowMenu(options);

                // Get option input and get index to match displayed index from menu
                int correctedIndex = GetInput() - 1;

                // Check if index is in range
                if (correctedIndex >= 0 && correctedIndex < options.Length)
                {
                    // If index is in range, return option string
                    menuOption = options[correctedIndex];
                }
                else
                {
                    // If index is not in range, return null
                    menuOption = null;
                }
            }
            // Repeat while the option chosen is null(bad input)
            while (menuOption == null);

            // Return the menu option that the user chooses
            return menuOption;
        }
    }
}
