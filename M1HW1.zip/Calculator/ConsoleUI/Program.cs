﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CalcLibrary;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            // Initialize variables
            string menuOption;

            // Main loop
            do
            {
                // Perform Main Loop actions
                menuOption = Loop.DoMain();

                // If user does not choose Exit
                if (menuOption != "Exit")
                {
                    // Run Sub loop
                    do
                    {
                        // Print space
                        Console.WriteLine();

                        // Run Sub Loop
                        menuOption = Loop.DoSub(menuOption);
                    }
                    // While user does not choose Main Menu
                    while (menuOption != "Main Menu");
                }
            }
            // While user does not choose Exit
            while (menuOption != "Exit");

            // Goodbye
            Console.WriteLine("Goodbye.");
            Console.ReadLine();
        }
    }
}
