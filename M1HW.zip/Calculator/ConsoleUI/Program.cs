﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CalcLibrary;

namespace ConsoleUI
{
    class Program
    {
        // Allows multiple inputs
        const int INPUT_AMOUNT = 2;
        static string[] menu1 = { "Add", "Subtract", "Divide", "Multiply", "Exit"};
        static string[] menu2 = { "Repeat", "Main Menu"};
        static void Main(string[] args)
        {
            string userInput = "Main Menu";

            // Main loop
            do
            {
                // If user wants to go to Main Menu
                if (userInput == "Main Menu")
                {
                    // Clean Console for cleanliness
                    Console.Clear();

                    // Display welcome message
                    Console.WriteLine("Welcome to the calculator program.");

                    // Display Menu 1 (Main Manu) and get input
                    userInput = UI.Menu(menu1);
                }

                // Else
                else
                {
                    // Initialize menu2 input
                    string repeatInput = "Repeat";

                    // Repeat Loop
                    do
                    {
                        // Print separator
                        Console.WriteLine();

                        // Display Option
                        Console.WriteLine(userInput);

                        // Initialize variables
                        int[] intInput = new int[INPUT_AMOUNT];     // User equation Int Array
                        char symbol;                                // Answer equation symbol
                        int ans;                                    // Answer integer

                        // Get user input
                        for (int i = 0; i < INPUT_AMOUNT; i++)
                        {
                            // Place user input into Int Array
                            intInput[i] = UI.InputToInt();
                        }

                        // Try to calculate numbers
                        try
                        {
                            // Switch depending on Option
                            switch (userInput)
                            {
                                // User wants to Add
                                case "Add":
                                    // Add numbers;
                                    ans = Calc.Add(intInput);

                                    // Change symbol to +
                                    symbol = '+';

                                    // Break
                                    break;

                                // User wants to Subtract
                                case "Subtract":
                                    // Subtract Numbers
                                    ans = Calc.Subtract(intInput);

                                    // Change symbol to -
                                    symbol = '-';
                                    
                                    // Break
                                    break;

                                // User wants to Divide
                                case "Divide":
                                    // Divide Numbers
                                    ans = Calc.Divide(intInput);

                                    // Change symbol to /
                                    symbol = '/';

                                    // Break
                                    break;

                                // User wants to Multiply
                                default:
                                    // Multiply Numbers
                                    ans = Calc.Multiply(intInput);

                                    // Change symbol to *
                                    symbol = '*';

                                    // Break
                                    break;
                            }

                            // Print answer
                            UI.ShowAnswer(intInput, ans, symbol);
                        }
                        catch(Exception e)
                        {
                            // User inputs bad input
                            Console.WriteLine(e.Message);
                        }

                        // Display Menu 2 (Second Menu) and get input
                        repeatInput = UI.Menu(menu2);
                    }
                    // While user wants to Repeat
                    while (repeatInput == "Repeat");

                    // Changes input back to Main Menu after user is done repeating
                    userInput = repeatInput;
                }
            }
            // While the user has not inputted "Exit"
            while (userInput != "Exit");

            // Display goodbye message
            Console.WriteLine("Goodbye.");

            // Wait for user input
            Console.ReadLine();
        }
    }
}
