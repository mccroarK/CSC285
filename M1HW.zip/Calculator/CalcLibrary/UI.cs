﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalcLibrary
{
    public static class UI
    {
        /// <summary>
        /// Displays a menu from an Option Array and returns a selected Option String
        /// </summary>
        /// <param name="menu"></param>
        /// <returns></returns>
        public static string Menu(string[] menu)
        {
            // Loop until good input
            while (true)
            {
                // Display Menu Array and get answer from user using an inputted index
                for (int i = 0; i < menu.Length; i++)
                {
                    Console.WriteLine($"{i + 1}. {menu[i]}");
                }

                // Try to get Option String from user input
                try
                {
                    // Get user input and return option string
                    return menu[InputToInt() - 1];
                }
                catch (Exception e)
                {
                    //If user inputs bad input
                    Console.WriteLine(e.Message);
                }
            }
        }

        /// <summary>
        /// Gets an integer input from users
        /// </summary>
        /// <returns></returns>
        public static int InputToInt()
        {
            // Loop until good input
            while (true)
            {
                // Prompt user
                Console.Write("Enter a number: ");

                // Get user input
                string input = Console.ReadLine();

                // Try to convert input to int
                try
                {
                    // Return good input
                    return int.Parse(input);
                }
                catch (Exception e)
                {
                    // If user inputs poor input, show error
                    Console.WriteLine(e.Message);
                }
            }
        }

        public static void ShowAnswer(int[] input, int ans, char symbol)
        {
            // Display answer equation
            for (int i = 0; i < input.Length; i++)
            {
                // Display input number
                Console.Write($"{input[i]}");

                // If number index is not last
                if (i < input.Length - 1)
                {
                    Console.Write($" {symbol} ");
                }
            }

            // Display answer
            Console.WriteLine($" = {ans}");
        }
    }
}
