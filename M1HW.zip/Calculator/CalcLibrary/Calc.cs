﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalcLibrary
{
    public static class Calc
    {
        public static int Add(int[] input)
        {
            // Initialize ans to first number in array
            int ans = input[0];

            // Loop to get answer
            for (int i = 1; i < input.Length; i++)
            {
                // Add to ans
                ans += input[i];
            }

            // Return ans
            return ans;
        }

        public static int Subtract(int[] input)
        {
            // Initialize ans to first number in array
            int ans = input[0];

            // Loop to get answer
            for (int i = 1; i < input.Length; i++)
            {
                // Subtract from ans
                ans -= input[i];
            }

            // Return ans
            return ans;
        }
        
        public static int Divide(int[] input)
        {
            // Initialize ans to first number in array
            int ans = input[0];

            // Loop to get answer
            for (int i = 1; i < input.Length; i++)
            {
                // Divide ans
                ans /= input[i];
            }

            // Return ans
            return ans;
        }

        public static int Multiply(int[] input)
        {
            // Initialize ans to first number in array
            int ans = input[0];

            // Loop to get answer
            for (int i = 1; i < input.Length; i++)
            {
                // Multiply ans
                ans *= input[i];
            }

            // Return ans
            return ans;
        }
    }
}
