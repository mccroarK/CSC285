﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CalcLibrary;

namespace ConsoleUI
{
    class Program
    {
        static string[] menu1 = { "Add", "Subtract", "Divide", "Multiply", "Exit"};
        static void Main(string[] args)
        {
            UI.Menu(menu1);
        }
    }
}
