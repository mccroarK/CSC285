﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalcLibrary
{
    public static class UI
    {
        public static void Menu(string[] menu)
        {
            // Display Menu Array and get answer from user using an inputted index
            for (int i = 0; i < menu.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {menu[i]}");
            }

            // Get user input
            int input = InputToInt();

        }

        public static int InputToInt()
        {
            // Loop until good input
            while (true)
            {
                // Prompt user
                Console.Write("Enter a number: ");

                // Get user input
                string input = Console.ReadLine();

                // Try to convert input to int
                try
                {
                    // Return good input
                    return int.Parse(input);
                }
                catch (Exception e)
                {
                    // If user inputs poor input, show error
                    Console.WriteLine(e.Message);
                }
            }
        }
    }
}
